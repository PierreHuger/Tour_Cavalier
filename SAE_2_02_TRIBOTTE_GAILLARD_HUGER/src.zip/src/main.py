from modules.chess import Chess, ChessType
from config import DEFAULT_CHESS_SIZE, MIN_CHESS_SIZE, MODE

# algos
from algos.algo1 import main as algo1
from algos.algo2 import main as algo2

# programme principale
if __name__ == '__main__':
    chess_size = DEFAULT_CHESS_SIZE
    if MODE == "prod":
        message = "Entrer la taille de l'échiquier: "
        chess_size = int(input(message))
        while chess_size < MIN_CHESS_SIZE:
            print(f'L\'échiquier ne peut pas être en dessous de {MIN_CHESS_SIZE}')
            chess_size = int(input(message))

    chess_graph = Chess(chess_size, ChessType.GRAPH)
    chess_list = Chess(chess_size, ChessType.LIST)

    # utilisation des algorithmes
    # chess_list.solve(algo1)
    chess_graph.solve(algo2)
