class Graphe(object):

    def __init__(self, graphe=None):
        if graphe is None:
            graphe = {}
        self._graphe = graphe

    """
        Récupérer les arêtes d'un voisin.
    """

    def aretes(self, sommet):
        return self._graphe[sommet]

    """
        Récupérer tous les sommets.
    """

    def all_sommets(self):
        return list(self._graphe.keys())

    """
    Récupérer la liste des arêtes
    """

    def all_aretes(self):
        return self._list_aretes()

    """
        Ajotuer un sommet
    """

    def add_sommet(self, sommet):
        if sommet not in self._graphe:
            self._graphe[sommet] = set()

    """
        Vérifier qu'un sommet existe dans le graphe
    """

    def has_sommet(self, sommet):
        return sommet in self._graphe

    """
    Ajouter une arête dans le graphe
    """

    def add_arete(self, arete):
        arete1, arete2 = tuple(arete)
        for a, b in [(arete1, arete2), (arete2, arete1)]:
            if a in self._graphe:
                self._graphe[a].add(b)
            else:
                self._graphe[a] = {b}

    """
        Lister les arêtes
    """

    def _list_aretes(self):
        aretes = []
        for sommet in self._graphe:
            for voisin in self.aretes(sommet):
                if ({voisin, sommet}) not in aretes:
                    aretes.append({sommet, voisin})
        return aretes

    """
        Afficher les sommets et les arêtes du graphe
        (Méthode magique)
    """

    def __str__(self):
        res = "sommets: "
        for k in self._graphe:
            res += str(k) + " "
        res += "\naretes: "
        for arete in self._list_aretes():
            res += str(arete) + " "
        return res
