from modules.chess import Chess, ChessType
from config import DEFAULT_CHESS_SIZE

DIR_NAME = "algos"
MAX_EVALUATION_EXECUTIONS = 100


class Evaluator:

    def __init__(self, chess_size=None):
        if chess_size is None:
            chess_size = DEFAULT_CHESS_SIZE
        self._chess_graph = Chess(chess_size, ChessType.GRAPH)
        self._chess_list = Chess(chess_size, ChessType.LIST)

        self._algos = []

    """
        Commencer l'évaluation des algorithmes en affichant le menu des choix.
    """

    def interactive(self):
        self._show_menu()
        res = int(input("Entrer un numéro: "))
        while res < 1 or res > 4:
            self._show_menu()
            res = int(input("Entrer un numéro: "))
        if res == 1:
            leaderboard = self.evaluate()
            print("Classement des meilleures algorithmes par temps d'éxécution:")
            index = 0
            for name, moy_exec_time in leaderboard:
                print(f'[{index + 1}] • {name} : {moy_exec_time}s en moyenne')
                index += 1
        elif res == 2:
            algoA, algoB = self._choose_algo(), self._choose_algo()
            print(f'Compraison entre {algoA[2]} et {algoB[2]}')
            self.compare_algos(algoA, algoB)
        elif res == 3:
            algo = self._choose_algo()
            time, name = self._execute(algo)
            print(f'Temps d\'execution pour {name}: {time}s')
        elif res == 4:
            print("Aurevoir 🎉")
            exit()
        self.interactive()

    """
        Lancer l'évaluation de tous les algorithmes
    """

    def evaluate(self):
        length = len(self._algos)
        result = {algo[2]: 0 for algo in self._algos}

        for _ in range(MAX_EVALUATION_EXECUTIONS):
            for i in range(length):
                for j in range(i + 1, length):
                    timeA, algoA_name = self._execute(self._algos[i])
                    timeB, algoB_name = self._execute(self._algos[j])

                    if timeA > timeB:
                        result[algoA_name] += timeA
                    elif timeA < timeB:
                        result[algoB_name] += timeB

        result = {k: format((v / MAX_EVALUATION_EXECUTIONS), ".4f") for k, v in result.items()}
        return sorted(
            result.items(),
            key=lambda x: x[1]
        )

    """
        Comparer deux algorithmes
    """

    def compare_algos(self, a, b):
        timeA, algoA_name = self._execute(a)
        timeB, algoB_name = self._execute(b)

        if timeA > timeB:
            print(f'{algoA_name} est plus rapide.')
        elif timeA < timeB:
            print(f'{algoB_name} est plus rapide.')
        else:
            print(f'Aucun algorithme n\'est plus rapide que l\'autre')

    """
        Exécuter un algorithme pour tester son temps d'exécution
    """

    def _execute(self, algo_data):
        algo, algo_type, algo_name = algo_data
        chess_type = None
        if algo_type == ChessType.GRAPH:
            chess_type = self._chess_graph
        elif algo_type == ChessType.LIST:
            chess_type = self._chess_list
        return chess_type.solve(algo, None, False), algo_name

    """
        Ajouter un algorithme à la liste des algorithmes
    """

    def add_algo(self, algo, algo_name):
        algo_func = algo.main
        algo_type = algo.get_algo_type()
        self._algos.append((algo_func, algo_type, algo_name))

    """
        Choisir parmit les algorithmes via un menu. Retourne l'algorithme choisit
    """

    def _choose_algo(self):
        length = len(self._algos)
        message = 'Entrer un numéro: '

        self._show_algos()
        res = int(input(message))
        while res < 1 or res > length:
            self._show_algos()
            res = int(input(message))
        return self._algos[res - 1]

    """
        Afficher le menu des choix
    """

    def _show_menu(self):
        line_length = 60
        print("-" * line_length)
        print("Veuillez séléctionner un mode d'évaluation:")
        print(f'[1] Evaluer tous les algorithmes. (évaluation sur {MAX_EVALUATION_EXECUTIONS} executions)')
        print("[2] Comparer un algorithme A avec un algorithme B")
        print("[3] Evaluer un algorithme")
        print("[4] Quitter le menu.")
        print("-" * line_length)

    """
        Afficher la liste des algorithmes.
    """

    def _show_algos(self):
        line_length = 60
        print("-" * line_length)
        print("Veuillez séléctionner un algorithme:")
        for i in range(len(self._algos)):
            print(f'[{i + 1}] {self._algos[i][2]}')
        print("-" * line_length)
