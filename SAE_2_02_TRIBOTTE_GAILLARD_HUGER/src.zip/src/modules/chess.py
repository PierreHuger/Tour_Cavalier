import random
from time import time
from enum import Enum
from modules.graphe import Graphe
from config import MIN_CHESS_SIZE, DEFAULT_CHESS_SIZE

INITIAL_CAVALIER = "ICC"
CAVALIER = "CC"


class ChessType(Enum):
    GRAPH = 0
    LIST = 1


"""
Utilitaire: formatter les nombres
"""


def format_number(i, j):
    return str(i) + str(j)

"""
Classe permettant de modéliser l'échiquier
"""

class Chess:

    def __init__(self, size=None, chess_type=None):
        if size is None:
            size = DEFAULT_CHESS_SIZE
        if chess_type is None:
            chess_type = ChessType.GRAPH  # par défaut, ce sera le type Graphe
        if size < MIN_CHESS_SIZE:
            print(f'Erreur: Le jeu d\'echec doit faire au moins {MIN_CHESS_SIZE}x{MIN_CHESS_SIZE}')
            exit()
        self._size = size
        self._chess_type = chess_type
        self._cavalier_positions = []

        self._data = None
        self._init_data()

    """
        Initaliser la table sous forme d'un graphe
    """

    def _init_graph_table(self):
        graph = {}
        for i in range(self._size):
            for j in range(self._size):
                graph[format_number(i, j)] = self.get_neighbors((i, j))
        self._data = Graphe(graph)

    """
       Récupérer la table sous forme d'une matrice m*n 
    """

    def _init_matrix_table(self):
        self._data = [[format_number(i, j) for j in range(self._size)] for i in range(self._size)]

    """
        Initialiser les données
    """

    def _init_data(self):
        if self._chess_type == ChessType.GRAPH:
            self._init_graph_table()
        elif self._chess_type == ChessType.LIST:
            self._init_matrix_table()
        else:
            print("Erreur: Impossible de trouver le format d'exportation.")
            exit()

    """
    Récupérer la taille de l'échiquier
    """

    def get_size(self):
        return self._size * self._size

    """
    Récupérer les données de l'échiquier soit sous forme d'une liste soit sous forme d'un graphe.
    """

    def get_data(self):
        return self._data

    """
    Récupérer le type de l'échiquier
    """

    def get_chess_type(self):
        return self._chess_type

    """
    Définir la position de départ du cavalier dans le plateau
    """

    def default_cavalier_position(self, data):
        if self._chess_type == ChessType.GRAPH:
            if self._data.has_sommet(data):
                self._cavalier_positions.append(data)
            else:
                print("Impossible de trouver la case dans le graphe.")
                exit()
        elif self._chess_type == ChessType.LIST:
            x, y = data
            if 0 <= x < self._size or 0 <= y < self._size:
                self._data[x][y] = INITIAL_CAVALIER
                self._cavalier_positions.append(data)
            else:
                print("Les coordonnées dépasse du tableau.")
                exit()

    """
    Récupérer les possibilités de déplacement par rapport à la dernière position
    """

    def get_neighbors(self, position):
        return self._get_cavalier_deplacements(*position)

    """
    Récupérer la dernière position du cavalier
    """

    def get_last_position(self):
        return self._cavalier_positions[-1]

    """
    Vérifier que le cavalier a une dernière position. (dans le cas contraire
    cela indique qu'il n'y pas de solution possible)
    """

    def has_last_position(self):
        return len(self._cavalier_positions) > 0

    """
    Revenir en arrière
    """

    def remove_last_position(self):
        self._cavalier_positions.pop()

    """
    Ajouter une position pour le cavalier.
    Note: la cavalier a un déplacement particulier. 
    """

    def add_position(self, data):
        if self._chess_type == ChessType.GRAPH:
            last_position = self.get_last_position()
            last_x, last_y = int(last_position[0]), int(last_position[1])

            if self._data.has_sommet(last_position):
                if data in self.get_neighbors((last_x, last_y)):
                    self._cavalier_positions.append(data)
                else:
                    print("⚠️Impossible de placer le cavalier ici.")
            else:
                print("⚠️Dernier sommet introuvable.")
        elif self._chess_type == ChessType.LIST:
            x, y = data
            if data in self.get_neighbors(self.get_last_position()):
                self._data[x][y] = CAVALIER
                self._cavalier_positions.append(data)
            else:
                print("⚠️Impossible de placer le cavalier ici.")

    """
    Récupérer les déplacements du cavalier par rapport à un point x et y
    """

    def _get_cavalier_deplacements(self, x, y):
        res = []

        def set_format(pos_x, pos_y):
            """
            Formatter les nombres pour avoir des coordonnées
            si une liste ou un nombre (ex "12") pour un graphe
            """
            cos = (pos_x, pos_y)
            return cos if self._chess_type == ChessType.LIST else format_number(*cos)

        cavalier_deplacements = [(2, 1), (1, 2), (-1, 2), (-2, 1), (-2, -1), (-1, -2), (1, -2), (2, -1)]
        for dx, dy in cavalier_deplacements:
            nx, ny = dx + x, dy + y
            if 0 <= nx < self._size and 0 <= ny < self._size and nx != x and ny != y:
                res.append(set_format(nx, ny))
        return res

    """
    Résoudre le problème grâce un algorithme passé en paramètre dans l'échiquier.
    """

    def solve(self, algo, initial_cavalier_position=None, show_execution_time=True):
        if initial_cavalier_position is None:
            x, y = (random.randint(0, self._size - 1), random.randint(0, self._size - 1))
            if self._chess_type == ChessType.GRAPH:
                initial_cavalier_position = format_number(x, y)
            elif self._chess_type == ChessType.LIST:
                initial_cavalier_position = (x, y)
        self.default_cavalier_position(initial_cavalier_position)

        print("Lancement de l'algorithme...")
        start = time()
        algo(self)
        diff = (time() - start)

        if show_execution_time:
            print("\033[0mTemps d'éxecution de l'algorithme:", diff, "s")
        self._cavalier_positions = []
        return diff

    """
    Afficher l'échiquier
    """

    def show(self):
        print("\033[0mLégende:")
        print("\033[0mCavalier initial: \033[1;34m◇")
        print("\033[0mDernières positions du cavalier: \033[1;32m◇")
        print("\033[0mCase vide: \033[1;31m•\n")

        if self._chess_type == ChessType.GRAPH:
            for i in range(self._size):
                line = ""
                offset = i * self._size
                for sommet in list(self._data.all_sommets())[offset:offset + self._size]:
                    line += (
                                "\033[1;32m◇" if sommet in self._cavalier_positions else
                                "\033[1;34m◇" if sommet == self._cavalier_positions[0]
                                else "\033[1;31m•"
                            ) + "   "
                print(line)
        elif self._chess_type == ChessType.LIST:
            for i in range(len(self._data)):
                line = ""
                for j in range(len(self._data[0])):
                    line += (
                                "\033[1;32m◇" if self._data[i][j] == CAVALIER else
                                "\033[1;34m◇" if self._data[i][j] == INITIAL_CAVALIER
                                else "\033[1;31m•"
                            ) + "   "
                print(line)
        print("\033[0m")
