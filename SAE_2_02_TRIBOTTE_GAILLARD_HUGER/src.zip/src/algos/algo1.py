from modules.chess import ChessType

"""
Algo 1
Cet algorithme utilise les matrices.
"""


def get_algo_type():
    return ChessType.LIST


def main(chess):
    path = solve(chess, chess.get_last_position())
    if not path:
        print("❌Aucune solution trouvée.")
    else:
        for position in path:
            chess.add_position(position)
            chess.show()


def solve(chess, position, path=None):
    if path is None:
        path = []

    path.append(position)
    if len(path) == chess.get_size():  # dès que le chemin est trouvé on le retourne.
        return path

    neighbors = get_neighbors_not_visited(chess, position, path)  # on récupère les voisins de notre position
    possibles_neighbors = [{
        "neighbor": neighbor,
        "length": len(get_neighbors_not_visited(chess, neighbor, path))
    } for neighbor in neighbors]
    possibles_neighbors.sort(key=lambda data: data["length"])  # trier les possibilités par ordre
    # croissant pour parcourir la plus petite distance en premier

    for neighbor in [data["neighbor"] for data in possibles_neighbors]:
        return solve(chess, neighbor, path)
    path.pop()
    return False  # si aucune solution n'est trouvée


"""
Permet de récupérer tous les voisins qui n'ont pas été déjà visités d'une position
"""


def get_neighbors_not_visited(chess, position, path):
    return [neighbor for neighbor in chess.get_neighbors(position) if neighbor not in path]
