from modules.chess import ChessType

"""
Algo 2
Cet algorithme utilise les graphes.
"""


def get_algo_type():
    return ChessType.GRAPH


def main(chess):
    path = solve(chess, chess.get_last_position())
    if not path:
        print("❌Aucune solution trouvée.")
    else:
        for sommet in path:
            chess.add_position(sommet)
            chess.show()


def solve(chess, sommet, path=None):
    if path is None:
        path = []

    path.append(sommet)
    if len(path) == chess.get_size():
        return path

    voisins = [voisin for voisin in chess.get_data().aretes(sommet) if voisin not in path]  # on récupère les voisins qui ne sont pas déjà dans le chemin
    voisins = sorted(voisins, key=lambda voisin: len([x for x in chess.get_data().aretes(voisin) if x not in path]))  # on tri les voisins par celui qui en a le moins.
    for voisin in voisins:
        if len(path) < chess.get_size() - 1 \
                and len([x for x in chess.get_data().aretes(voisin) if x not in path]) == 0:
            continue  # si tous les voisins ont été visités, sauter ce voisin
        return solve(chess, voisin, path)
    path.pop()
    return False


