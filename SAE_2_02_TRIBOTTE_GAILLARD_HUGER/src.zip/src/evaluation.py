from modules.evaluator import Evaluator
from config import DEFAULT_CHESS_SIZE, MIN_CHESS_SIZE, MODE

# algos
import algos.algo1 as algo1
import algos.algo2 as algo2

# tester le mode évaluation
if __name__ == '__main__':
    chess_size = DEFAULT_CHESS_SIZE
    if MODE == "prod":
        message = "Entrer la taille de l'échiquier: "
        chess_size = int(input(message))
        while chess_size < MIN_CHESS_SIZE:
            print(f'L\'échiquier ne peut pas être en dessous de {MIN_CHESS_SIZE}')
            chess_size = int(input(message))

    evaluator = Evaluator(chess_size)

    # ajout des algorithmes
    for algo, label in [(algo1, "Algorithme Matrice"), (algo2, "Algorithme Graphe")]:
        evaluator.add_algo(algo, label)

    # menu des algos
    evaluator.interactive()
