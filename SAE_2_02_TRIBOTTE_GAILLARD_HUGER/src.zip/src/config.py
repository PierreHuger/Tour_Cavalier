# config
MIN_CHESS_SIZE = 5
DEFAULT_CHESS_SIZE = 8
MODE = "prod"  # ou "prod" pour mettre en mode production
